﻿# Implement Fibonnaci sequence for negative numbers

def fib_alg(n):
    if n == 0:
        return 0

    if n in {1,2}:
        return 1

    return fib_alg(n-1) + fib_alg(n-2)


def fibonacci(n):
    fib_number = fib_alg(abs(n))

    negate_and_even = (n < 1) and ((n % 2) == 0)
    if negate_and_even:
        return -fib_number

    return fib_number

sequence = ""
numbers = ""
for n in range(-10, 11):
    sequence += f"{n}, "
    numbers += f"{fibonacci(n)}, "

print("number:", sequence.strip(", "))
print("result:", numbers.strip(", "))