import os

from app import create_app
from app.routes import main

# Create app
app = create_app()

# Register blueprints
app.register_blueprint(main)


# Handle 404 pages
@app.errorhandler(404)
def not_found(e):
    return "404 Page not found", 404


if __name__ == "__main__":
    HOST = os.environ.get("HOST", "0.0.0.0")
    PORT = os.environ.get("PORT", 8080)
    DEBUG = os.environ.get("PORT", True)
    app.run(host=HOST, port=PORT, debug=DEBUG)
