﻿def test_index(client):
    response = client.get("/")

    assert response.status_code == 200
    assert response.content_type == "text/html; charset=utf-8"
    assert b"<!DOCTYPE html>" in response.data

def test_livez(client):
    response = client.get("/livez")

    assert response.status_code == 200
    assert response.is_json
    assert response.json == {"ping": "ok"}

def test_recommend_success(client):
    response = client.get("/api/v1/recommend/movies")
    assert response.status_code == 200
    assert response.is_json
    assert len(response.json) == 1

    response = client.get("/api/v1/recommend/movies?title=Kingpin")
    assert response.status_code == 200
    assert response.is_json
    assert len(response.json) >= 2

    response = client.get("/api/v1/recommend/movies?title=Lost%20in%20Translation")
    assert response.status_code == 200
    assert response.is_json
    assert len(response.json) >= 5