﻿import random


class RecommendationEngine():
    def __init__(self, db):
        self.db = db

    def recommend(self,
                query_params,
                reference_key="title",
                comparison_features=["genre", "stars"],
                sort_key="rating"
        ):
        reference_value = query_params.get(reference_key, "")
        reference_item = self.__get_item_by(reference_key, reference_value)
        if not reference_item:
            return self.__random_recommendation()

        recommendations = []
        for item in self.db:
            if item[reference_key] != reference_value:
                for feature in comparison_features:
                    feature_match = [fm in item[feature] for fm in reference_item[feature]]
                    if any(feature_match):
                        recommendations.append(item)
                        break

        return sorted(recommendations, key=lambda recommendation: recommendation[sort_key], reverse=True)

    def __get_item_by(self, key, value):
        item = list(filter(lambda item: item[key] == value, self.db))
        return item[0] if item else None

    def __random_recommendation(self):
        return [random.choice(self.db)]
