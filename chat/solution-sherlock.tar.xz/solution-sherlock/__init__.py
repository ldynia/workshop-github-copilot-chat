import os
import sys

from flask import Flask

# Get the absolute path of the directory where this script is located
APP_DIR = os.path.dirname(os.path.realpath(__file__))

# Add APP_DIR directory to PYTHONPATH
sys.path.append(APP_DIR)

from app.rengine import RecommendationEngine
from app.loaders import JSONFileDataLoader


db_data = JSONFileDataLoader.load(f"{APP_DIR}/db.json")
engine = RecommendationEngine(db_data)


# Create the Flask app
def create_app():
    app = Flask(__name__)
    app.json.ensure_ascii = False
    return app
