﻿from flask import Blueprint
from flask import jsonify
from flask import render_template
from flask import request

from app import engine


main = Blueprint("main", __name__,)


@main.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@main.route("/livez", methods=["GET"])
def alive():
    return jsonify({"ping": "ok"})


@main.route("/api/v1/recommend/movies", methods=["GET"])
def recommend():
    recommendations = engine.recommend(request.args)

    return jsonify(recommendations)