﻿import json


class DataLoader:
    @staticmethod
    def load(source):
        raise NotImplementedError("load() method is not implemented.")

class JSONFileDataLoader(DataLoader):
    def load(source):
        try:
            with open(source) as db:
                content = db.read()
            return json.loads(content)
        except Exception as e:
            raise Exception(f"Reading {source}, {str(e)}")